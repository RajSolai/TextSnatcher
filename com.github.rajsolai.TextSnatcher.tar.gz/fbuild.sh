
flatpak-builder build  com.github.rajsolai.TextSnatcher.yml --user --install --force-clean